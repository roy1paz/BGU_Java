import java.util.List;
import java.util.ArrayList;
public class Main{

    public static void main(String[] args){
        AVL tree = new AVL();
        tree.insert(5,null);
//        tree.insert(7,null);
//        tree.insert(8,null);
//        tree.insert(5,null);
////
//        tree.insert(6,null);
//        tree.insert(21,null);
//        tree.insert(3,null);
//        System.out.println(tree.getRoot());
//        System.out.println(tree.getRoot().toString());
//        System.out.println(tree.getRoot().getLeftChild());
//        System.out.println(tree.getRoot().getRightChild());
//        System.out.println(tree.getRoot().getRightChild());

//        HashTable Hash = new HashTable(5);
//        ObjectWithCoordinatesImpl Point1 = new ObjectWithCoordinatesImpl(null,5,6);
//        ObjectWithCoordinatesImpl Point2 = new ObjectWithCoordinatesImpl(null,5,4);
//        ObjectWithCoordinatesImpl Point3 = new ObjectWithCoordinatesImpl(null,4,5);
//        ObjectWithCoordinatesImpl Point4 = new ObjectWithCoordinatesImpl(null,2,99);
//
//        Hash.insert(Point1);
//        Hash.insert(Point2);
//        Hash.insert(Point3);
//        Hash.insert(Point4);
//
//       StudentSolution Test = new StudentSolution();
//       Test.XAvl.insert(5,null);
//       Test.XAvl.insert(7,null);
//       Test.XAvl.insert(8,null);
//       Test.XAvl.insert(10,null);
//        ArrayList aaa = new ArrayList();
//       Test.FindPath(Test.XAvl.getRoot(),Test.XAvl.getRoot().getRightChild(),aaa);





        //System.out.println(tree.getRoot().toString());
        //System.out.println(tree.getRoot().getLeftChild().toString());













    }
}